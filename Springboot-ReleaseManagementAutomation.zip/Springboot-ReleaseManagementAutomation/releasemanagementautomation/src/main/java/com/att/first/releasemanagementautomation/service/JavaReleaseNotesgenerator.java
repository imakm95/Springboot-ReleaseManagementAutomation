package com.att.first.releasemanagementautomation.service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.GroupLayout.Alignment;

import com.att.first.releasemanagementautomation.bean.JavaReleaseNotesBean;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.sl.usermodel.ColorStyle;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class JavaReleaseNotesgenerator {
	 private static String[] columns = {"Backup needed prior to deployment?", "Executable name", "Source Server", "Source Directory",
			 							"Destination TEST Server", "Destination TEST Directory/Console", "Destination Server",
			 							"Destination Directory/Console", "USERNAME", "CHMOD", "Offshore Owner","Onshore Owner",
			 							"RM/CR/PID", "Comments/Description", "SVN PATH", "Release Coordinator"};
	 private static List<JavaReleaseNotesBean> javaNotesEntries =  new ArrayList<>();
	 
	 static {
		 JavaReleaseNotesBean javaReleaseNotesBean = new JavaReleaseNotesBean("No", "GenrePackageAddLoader.sh", "zlt07296.vci.att.com", "/first/sbc/java/wrkspc/R1908_27/Scripts", "zlt07294.vci.att.com", 
				  "/first/sbc/cmd/sql/sqlload/GenrePackage", "zlp10079.vci.att.com", "/first/sbc/cmd/sql/sqlload/GenrePackage", "FIRST", "755", "Rahul/Dhiraj",
				  "Varun", "RD 2368 CR 1907-0521", "RD 2368 CR 1907-0521 - Combo Package Cleanup NBA League Pass 2019-20 Season Auto Renewals", 
				  "https://codecloud.web.att.com/projects/ST_FIRSTDB/repos/app_svc1/browse/first/sdaf/java/properties/csiVersion.properties?at=refs%2Fheads%2FDevelopment_R1908", "Rahul");
		 
		 javaNotesEntries.add(javaReleaseNotesBean);		
	 }
	 
	 public static void main(String[] args) throws IOException, InvalidFormatException {
	        // Create a Workbook
	        Workbook workbook = new XSSFWorkbook(); // new HSSFWorkbook() for generating `.xls` file

	        /* CreationHelper helps us create instances of various things like DataFormat, 
	           Hyperlink, RichTextString etc, in a format (HSSF, XSSF) independent way */
	        CreationHelper createHelper = workbook.getCreationHelper();

	        // Create a Sheet
	        Sheet sheet = workbook.createSheet("Files(night)");

	        // Create a Font for styling header cells
	        Font headerFont = workbook.createFont();
	        headerFont.setBold(true);
	        headerFont.setFontHeightInPoints((short) 10);
	        headerFont.setFontName("Calibri");
	        headerFont.setColor(IndexedColors.BLACK.getIndex());
	        
	        // Create a CellStyle with the font
	        XSSFCellStyle headerCellStyle = (XSSFCellStyle) workbook.createCellStyle();
	        XSSFCellStyle testHeaderCellStyle = (XSSFCellStyle) workbook.createCellStyle();
	        headerCellStyle.setFont(headerFont);
	        headerCellStyle.setAlignment(HorizontalAlignment.CENTER);
	        headerCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
	        headerCellStyle.setBorderBottom(BorderStyle.THIN);	  
	        headerCellStyle.setBorderTop(BorderStyle.THIN);
	        headerCellStyle.setBorderLeft(BorderStyle.THIN);
	        headerCellStyle.setBorderRight(BorderStyle.THIN);
	        headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	        //headerCellStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
	        headerCellStyle.setFillForegroundColor(new XSSFColor(new java.awt.Color(255,255,0)));
	        headerCellStyle.setWrapText(true);
	        
	        testHeaderCellStyle.setFont(headerFont);
	        testHeaderCellStyle.setAlignment(HorizontalAlignment.CENTER);
	        testHeaderCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
	        testHeaderCellStyle.setBorderBottom(BorderStyle.THIN);	  
	        testHeaderCellStyle.setBorderTop(BorderStyle.THIN);
	        testHeaderCellStyle.setBorderLeft(BorderStyle.THIN);
	        testHeaderCellStyle.setBorderRight(BorderStyle.THIN);
	        testHeaderCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	        testHeaderCellStyle.setFillForegroundColor(new XSSFColor(new java.awt.Color(198,89,17)));
	        testHeaderCellStyle.setWrapText(true);
	        // Create a Row
	        Row headerRow = sheet.createRow(0);

	        // Create cells
	        for(int i = 0; i < columns.length; i++) {
	            Cell cell = headerRow.createCell(i);
	            cell.setCellValue(columns[i]);
	            if(columns[i].contains("TEST")) {
	            	System.out.println("brown");
	            	cell.setCellStyle(testHeaderCellStyle);
	            	 
	            } else {
	            	System.out.println("yellow");
	            	cell.setCellStyle(headerCellStyle);
	            }
	            
	        }
	        
	        Font normalFont = workbook.createFont();
	        normalFont.setBold(false);
	        normalFont.setFontHeightInPoints((short) 9);
	        normalFont.setFontName("Calibri");
	        normalFont.setColor(IndexedColors.BLACK.getIndex());
	        
	        XSSFCellStyle normalCellStyle = (XSSFCellStyle) workbook.createCellStyle();
	        normalCellStyle.setFont(normalFont);
	        normalCellStyle.setAlignment(HorizontalAlignment.CENTER);
	        normalCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
	        normalCellStyle.setBorderBottom(BorderStyle.THIN);	  
	        normalCellStyle.setBorderTop(BorderStyle.THIN);
	        normalCellStyle.setBorderLeft(BorderStyle.THIN);
	        normalCellStyle.setBorderRight(BorderStyle.THIN);
	        normalCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	        normalCellStyle.setFillForegroundColor(new XSSFColor(new java.awt.Color(255,255,255)));
	        normalCellStyle.setWrapText(true);
	        
	        // Create Other rows and cells with employees data
	        int rownum = 1;
	        for(JavaReleaseNotesBean javaNotesEntry: javaNotesEntries) {
	        	Row row = sheet.createRow(rownum++);
	        	
	        		Cell rowCell1 = row.createCell(0);
	        		rowCell1.setCellValue(javaNotesEntry.getBackupNeeded());
	        		rowCell1.setCellStyle(normalCellStyle);
	        		
	        		Cell rowCell2 = row.createCell(1);
	        		rowCell2.setCellValue(javaNotesEntry.getExecutableName());
	        		rowCell2.setCellStyle(normalCellStyle);
	        		
	        		Cell rowCell3 = row.createCell(2);
	        		rowCell3.setCellValue(javaNotesEntry.getSourceServer());
	        		rowCell3.setCellStyle(normalCellStyle);
	        		
	        		Cell rowCell4 = row.createCell(3);
	        		rowCell4.setCellValue(javaNotesEntry.getSourceDir());
	        		rowCell4.setCellStyle(normalCellStyle);
	        		
	        		Cell rowCell5 = row.createCell(4);
	        		rowCell5.setCellValue(javaNotesEntry.getDestinationTestServer());
	        		rowCell5.setCellStyle(normalCellStyle);
	        		
	        		Cell rowCell6 = row.createCell(5);
	        		rowCell6.setCellValue(javaNotesEntry.getDestinationTestDir());
	        		rowCell6.setCellStyle(normalCellStyle);
	        		
	        		Cell rowCell7 = row.createCell(6);
	        		rowCell7.setCellValue(javaNotesEntry.getDestinationProdServer());
	        		rowCell7.setCellStyle(normalCellStyle);
	        		
	        		Cell rowCell8 = row.createCell(7);
	        		rowCell8.setCellValue(javaNotesEntry.getDestinationProdDir());
	        		rowCell8.setCellStyle(normalCellStyle);
	        		
	        		Cell rowCell9 = row.createCell(8);
	        		rowCell9.setCellValue(javaNotesEntry.getUsername());
	        		rowCell9.setCellStyle(normalCellStyle);
	        		
	        		Cell rowCell10 = row.createCell(9);
	        		rowCell10.setCellValue(javaNotesEntry.getChmod());
	        		rowCell10.setCellStyle(normalCellStyle);
	        		
	        		Cell rowCell11 = row.createCell(10);
	        		rowCell11.setCellValue(javaNotesEntry.getOffshoreOwner());
	        		rowCell11.setCellStyle(normalCellStyle);
	        		
	        		Cell rowCell12 = row.createCell(11);
	        		rowCell12.setCellValue(javaNotesEntry.getOnshoreOwner());
	        		rowCell12.setCellStyle(normalCellStyle);
	        		
	        		Cell rowCell13 = row.createCell(12);
	        		rowCell13.setCellValue(javaNotesEntry.getWorkItemId());
	        		rowCell13.setCellStyle(normalCellStyle);
	        		
	        		Cell rowCell14 = row.createCell(13);
	        		rowCell14.setCellValue(javaNotesEntry.getComments());
	        		rowCell14.setCellStyle(normalCellStyle);
	        		
	        		Cell rowCell15 = row.createCell(14);
	        		rowCell15.setCellValue(javaNotesEntry.getPath());
	        		rowCell15.setCellStyle(normalCellStyle);
	        		
	        		Cell rowCell16 = row.createCell(15);
	        		rowCell16.setCellValue(javaNotesEntry.getCoordinator());
	        		rowCell16.setCellStyle(normalCellStyle);
	        		
	        		/*row.createCell(0).setCellValue(javaNotesEntry.getBackupNeeded());
		            row.createCell(1).setCellValue(javaNotesEntry.getExecutableName());
		            row.createCell(2).setCellValue(javaNotesEntry.getSourceServer());
		            row.createCell(3).setCellValue(javaNotesEntry.getSourceDir());
		            row.createCell(4).setCellValue(javaNotesEntry.getDestinationTestServer());
		            row.createCell(5).setCellValue(javaNotesEntry.getDestinationTestDir());
		            row.createCell(6).setCellValue(javaNotesEntry.getDestinationProdServer());
		            row.createCell(7).setCellValue(javaNotesEntry.getDestinationProdDir());
		            row.createCell(8).setCellValue(javaNotesEntry.getUsername());	            
		            row.createCell(9).setCellValue(javaNotesEntry.getChmod());
		            row.createCell(10).setCellValue(javaNotesEntry.getOffshoreOwner());
		            row.createCell(11).setCellValue(javaNotesEntry.getOnshoreOwner());
		            row.createCell(12).setCellValue(javaNotesEntry.getWorkItemId());      
		            row.createCell(13).setCellValue(javaNotesEntry.getComments());
		            row.createCell(14).setCellValue(javaNotesEntry.getPath());
		            row.createCell(15).setCellValue(javaNotesEntry.getCoordinator()); */
	        	     	            
	        }
	        
	        // Resize all columns to fit the content size
	      //  for(int i = 0; i < columns.length; i++) {
	            //sheet.autoSizeColumn(i);
	        	sheet.setColumnWidth(0, 15*256);
	        	sheet.setColumnWidth(1, 40*256);
	        	sheet.setColumnWidth(2, 25*256);
	        	sheet.setColumnWidth(3, 46*256);
	        	sheet.setColumnWidth(4, 25*256);
	        	sheet.setColumnWidth(5, 46*256);
	        	sheet.setColumnWidth(6, 25*256);
	        	sheet.setColumnWidth(7, 46*256);
	        	sheet.setColumnWidth(8, 14*256);
	        	sheet.setColumnWidth(9, 14*256);
	        	sheet.setColumnWidth(10, 20*256);
	        	sheet.setColumnWidth(11, 18*256);
	        	sheet.setColumnWidth(12, 15*256);
	        	sheet.setColumnWidth(13, 50*256);
	        	sheet.setColumnWidth(14, 55*256);
	        	sheet.setColumnWidth(15, 20*256);
	       // }
	        
	        // Write the output to a file
	        FileOutputStream fileOut = new FileOutputStream("H://Desktop/DemoReleaseNotes.xlsx");
	        workbook.write(fileOut);
	        fileOut.close();

	        // Closing the workbook
	        workbook.close();
	 }
}
