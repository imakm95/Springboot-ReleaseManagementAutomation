package com.att.first.releasemanagementautomation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReleasemanagementautomationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReleasemanagementautomationApplication.class, args);
	}

}
