package com.att.first.releasemanagementautomation.bean;

public class JavaReleaseNotesBean {

	private String backupNeeded;
	private String executableName;
	private String sourceServer;
	private String sourceDir;
	private String destinationTestServer;
	private String destinationTestDir;
	private String destinationProdServer;
	private String destinationProdDir;
	private String username;
	private String chmod;
	private String offshoreOwner;
	private String onshoreOwner;
	private String workItemId;
	private String comments;
	private String path;
	private String coordinator;

	public JavaReleaseNotesBean() {
		super();
	}

	public JavaReleaseNotesBean(String backupNeeded, String executableName, String sourceServer, String sourceDir,
			String destinationTestServer, String destinationTestDir, String destinationProdServer,
			String destinationProdDir, String username, String chmod, String offshoreOwner, String onshoreOwner,
			String workItemId, String comments, String path, String coordinator) {
		super();
		this.backupNeeded = backupNeeded;
		this.executableName = executableName;
		this.sourceServer = sourceServer;
		this.sourceDir = sourceDir;
		this.destinationTestServer = destinationTestServer;
		this.destinationTestDir = destinationTestDir;
		this.destinationProdServer = destinationProdServer;
		this.destinationProdDir = destinationProdDir;
		this.username = username;
		this.chmod = chmod;
		this.offshoreOwner = offshoreOwner;
		this.onshoreOwner = onshoreOwner;
		this.workItemId = workItemId;
		this.comments = comments;
		this.path = path;
		this.coordinator = coordinator;
	}

	public String getBackupNeeded() {
		return backupNeeded;
	}

	public void setBackupNeeded(String backupNeeded) {
		this.backupNeeded = backupNeeded;
	}

	public String getExecutableName() {
		return executableName;
	}

	public void setExecutableName(String executableName) {
		this.executableName = executableName;
	}

	public String getSourceServer() {
		return sourceServer;
	}

	public void setSourceServer(String sourceServer) {
		this.sourceServer = sourceServer;
	}

	public String getSourceDir() {
		return sourceDir;
	}

	public void setSourceDir(String sourceDir) {
		this.sourceDir = sourceDir;
	}

	public String getDestinationTestServer() {
		return destinationTestServer;
	}

	public void setDestinationTestServer(String destinationTestServer) {
		this.destinationTestServer = destinationTestServer;
	}

	public String getDestinationTestDir() {
		return destinationTestDir;
	}

	public void setDestinationTestDir(String destinationTestDir) {
		this.destinationTestDir = destinationTestDir;
	}

	public String getDestinationProdServer() {
		return destinationProdServer;
	}

	public void setDestinationProdServer(String destinationProdServer) {
		this.destinationProdServer = destinationProdServer;
	}

	public String getDestinationProdDir() {
		return destinationProdDir;
	}

	public void setDestinationProdDir(String destinationProdDir) {
		this.destinationProdDir = destinationProdDir;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getChmod() {
		return chmod;
	}

	public void setChmod(String chmod) {
		this.chmod = chmod;
	}

	public String getOffshoreOwner() {
		return offshoreOwner;
	}

	public void setOffshoreOwner(String offshoreOwner) {
		this.offshoreOwner = offshoreOwner;
	}

	public String getOnshoreOwner() {
		return onshoreOwner;
	}

	public void setOnshoreOwner(String onshoreOwner) {
		this.onshoreOwner = onshoreOwner;
	}

	public String getWorkItemId() {
		return workItemId;
	}

	public void setWorkItemId(String workItemId) {
		this.workItemId = workItemId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getCoordinator() {
		return coordinator;
	}

	public void setCoordinator(String coordinator) {
		this.coordinator = coordinator;
	}
}
