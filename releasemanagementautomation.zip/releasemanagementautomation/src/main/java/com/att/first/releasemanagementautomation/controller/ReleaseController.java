package com.att.first.releasemanagementautomation.controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.att.first.releasemanagementautomation.bean.JavaReleaseNotesBean;
import com.att.first.releasemanagementautomation.service.JavaReleaseNotesGenerator;

@Controller

public class ReleaseController {

    // inject via application.properties
    @Value("${welcome.message}")
    private String message;
 
    @GetMapping("/")
    public String login() {
        return "index"; //view
    }
    
    @GetMapping("/welcome")
    public String home(Model model) throws EncryptedDocumentException, InvalidFormatException, IOException {
    	JavaReleaseNotesGenerator generator = new JavaReleaseNotesGenerator();
    	Map<String,List<String>> serverListMappings = generator.readConfigs();
    	model.addAttribute("sourceServerList", serverListMappings.get("sourceServerList"));
    	model.addAttribute("destinationTestServerList", serverListMappings.get("destinationTestServerList"));
    	model.addAttribute("destinationProdServerList", serverListMappings.get("destinationProdServerList"));
    	model.addAttribute("columnsList", serverListMappings.get("columnsList"));
    	model.addAttribute("entryList", generator.getAllJavaEntries());
        return "welcome"; 
    }
    
    @RequestMapping(value = "/saveFilesDay", method = RequestMethod.GET)
	public @ResponseBody String saveFilesDay(@RequestParam(value = "backupNeeded", required = true) String backupNeeded,
			@RequestParam(value = "executableName", required = true) String executableName,
			@RequestParam(value = "sourceServer", required = true) String sourceServer,
			@RequestParam(value = "sourceDirectory", required = true) String sourceDirectory,
			@RequestParam(value = "destinationTestServer", required = true) String destinationTestServer,
			@RequestParam(value = "destinationTestDirectory", required = true) String destinationTestDirectory, 
			@RequestParam(value = "destinationProdServer", required = true) String destinationProdServer, 
			@RequestParam(value = "destinationProdDirectory", required = true) String destinationProdDirectory, 
			@RequestParam(value = "username", required = true) String username, 
			@RequestParam(value = "chmod", required = true) int chmod, 
			@RequestParam(value = "offshoreOwner", required = true) String offshoreOwner, 
			@RequestParam(value = "onshoreOwner", required = true) String onshoreOwner, 
			@RequestParam(value = "workItemId", required = true) String workItemId, 
			@RequestParam(value = "comments", required = true) String comments, 
			@RequestParam(value = "path", required = true) String path, 
			HttpServletRequest request) throws InvalidFormatException, IOException {
    	System.out.println("HI");
		System.out.println("[backupNeeded]: " + backupNeeded);
		System.out.println("[executableName]: " + executableName);
		System.out.println("[sourceServer]: " + sourceServer);
		System.out.println("[sourceDirectory]: " + sourceDirectory);
		System.out.println("[destinationTestServer]: " + destinationTestServer);
		System.out.println("[destinationTestDirectory]: " + destinationTestDirectory);
		System.out.println("[destinationProdServer]: " + destinationProdServer);
		System.out.println("[destinationProdDirectory]: " + destinationProdDirectory);
		System.out.println("[username]: " + username);
		System.out.println("[chmod]: " + chmod);
		System.out.println("[offshoreOwner]: " + offshoreOwner);
		System.out.println("[onshoreOwner]: " + onshoreOwner);
		System.out.println("[workItemId]: " + workItemId);
		System.out.println("[comments]: " + comments);
		System.out.println("[path]: " + path);
		
		JavaReleaseNotesBean bean = new JavaReleaseNotesBean();

		bean.setBackupNeeded(backupNeeded);
		bean.setExecutableName(executableName);
		bean.setSourceServer(sourceServer);
		bean.setSourceDir(sourceDirectory);
		bean.setDestinationTestServer(destinationTestServer);
		bean.setDestinationTestDir(destinationTestDirectory);
		bean.setDestinationProdServer(destinationProdServer);
		bean.setDestinationProdDir(destinationProdDirectory);
		bean.setUsername(username);
		bean.setChmod(((Integer) chmod).toString());
		bean.setOffshoreOwner(offshoreOwner);
		bean.setOnshoreOwner(onshoreOwner);
		bean.setWorkItemId(workItemId);
		bean.setComments(comments);
		bean.setPath(path);
			
		JavaReleaseNotesGenerator generator = new JavaReleaseNotesGenerator();
		generator.generate(bean);
		return "SUCCESS";
		}

}