function saveFilesDay() {

	var backupNeeded = $('#backupNeeded').val();
	var executableName = $('#executableName').val();
	var sourceServer = $('#sourceServer').val();
	var sourceDirectory = $('#sourceDirectory').val();
	var destinationTestServer = $('#destinationTestServer').val();
	var destinationTestDirectory = $('#destinationTestDirectory').val();
	var destinationProdServer = $('#destinationProdServer').val();
	var destinationProdDirectory = $('#destinationProdDirectory').val();
	var username = $('#username').val();
	var chmod = $('#chmod').val();
	var offshoreOwner = $('#offshoreOwner').val();
	var onshoreOwner = $('#onshoreOwner').val();
	var workItemId = $('#workItemId').val();
	var comments = $('#comments').val();
	var path = $('#path').val();

	$.ajax({
		type : "GET",
		contentType : "application/json",
		url : "saveFilesDay?backupNeeded=" + backupNeeded + "&executableName=" + executableName + "&sourceServer=" 
		+ sourceServer + "&sourceDirectory=" + sourceDirectory + "&destinationTestServer=" + destinationTestServer
		+ "&destinationTestDirectory=" + destinationTestDirectory + "&destinationProdServer=" + destinationProdServer
		+ "&destinationProdDirectory=" + destinationProdDirectory + "&username=" + username + "&chmod=" + chmod + "&offshoreOwner=" 
		+ offshoreOwner + "&onshoreOwner=" + onshoreOwner + "&workItemId=" + workItemId + "&comments=" + comments + "&path=" + path,
		dataType : 'text',
		timeout : 100000,
		success : function(data) {
			if (data == "SUCCESS" || data == "success") {
				alert(data);
				/*document.forms['dayfilesform'].reset();*/

			} else {
				  alert("failure");
			}

		},
		error : function(e) {
			  alert("error")
			  console.log(e);
		}

		
	});
}
